# Tucil Stima 1 13518021
1. Deskripsi Singkat :
 - Program merupakan program bahasa python yang dapat memecahkan teka-teki cryptarithmetic dengan menggunakan metode brute force
2. Requirement program :
- instalasi library "timeit" untuk menghitung jam
3. Cara menggunakan program
    - ganti nama file teka-teki pada cryptarithmetic.py sesuai nama file teka-teki yang diinginkan
    - Jalankan program menggunakan "python3 ./src/cryptarithmetic.py"
4. Author
   Zaidan Naufal Sudrajat / 13518021


